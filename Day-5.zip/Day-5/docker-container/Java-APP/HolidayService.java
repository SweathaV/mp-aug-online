public class HolidayService {
	
	public static void main(String s[]) {
		System.out.println("Let us travel in a Docker container!!");
	}

}